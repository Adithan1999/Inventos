from django.urls import path
from . import views

urlpatterns=[
    #landing
    path('',views.index,name='index'),
    path('Signup',views.Signup,name='Signup'),
    path('adminindex',views.adminindex,name='adminindex'),
    path('forgetpass',views.forgetpass,name='forgetpass'),
    #dashboard
    path('dashboardindex',views.dashboardindex,name='dashboardindex'),
    path('categorylist',views.categorylist,name='categorylist'),
    path('login',views.login,name='login'),
    path('productadd',views.productadd,name='productadd'),
    path('productlist',views.productlist,name='productlist'),
    path('purchaseadd',views.purchaseadd,name='purchaseadd'),
    path('purchaselist',views.purchaselist,name='purchaselist'),
    path('quotationlist',views.quotationlist,name='quotationlist'),
    path('quotationsadd',views.quotationsadd,name='quotationsadd'),
    path('return_product',views.return_product,name='return_product'),
    path('sales_list',views.sales_list,name='sales_list'),
    path('stock_transfer_add',views.stock_transfer_add,name='stock_transfer_add'),
    path('stock_transfer_list',views.stock_transfer_list,name='stock_transfer_list'),
    path('taxlist',views.taxlist,name='taxlist'),
    path('unitlist',views.unitlist,name='unitlist'),
    path('UserManagementAdd',views.UserManagementAdd,name='UserManagementAdd'),
    path('UserManagementView',views.UserManagementView,name='UserManagementView'),
  
    
]