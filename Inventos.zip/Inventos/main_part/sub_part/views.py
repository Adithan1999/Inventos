from django.shortcuts import render

# Create your views here.
#Landing
def index(request):
    return render(request,'landing/index.html')

def Signup(request):
    return render(request,'landing/Signup.html')

def adminindex(request):
    return render(request,'landing/admin index.html')

def forgetpass(request):
    return render(request,'landing/forgetpass.html')

#Dashboard
def dashboardindex(request):
    return render(request,'dashboard/dashboardindex.html')

def categorylist(request):
    return render(request,'dashboard/categorylist.html')

def login(request):
    return render(request,'dashboard/login.html')

def productadd(request):
    return render(request,'dashboard/productadd.html')

def productlist(request):
    return render(request,'dashboard/productlist.html')

def purchaseadd(request):
    return render(request,'dashboard/purchaseadd.html')

def purchaselist(request):
    return render(request,'dashboard/purchaselist.html')

def quotationlist(request):
    return render(request,'dashboard/quotationlist.html')

def quotationsadd(request):
    return render(request,'dashboard/quotationsadd.html')

def return_product(request):
    return render(request,'dashboard/return_product.html')

def sales_list(request):
    return render(request,'dashboard/sales_list.html')

def stock_transfer_add(request):
    return render(request,'dashboard/stock_transfer_add.html')

def stock_transfer_list(request):
    return render(request,'dashboard/stock_transfer_list.html')

def taxlist(request):
    return render(request,'dashboard/taxlist.html')

def unitlist(request):
    return render(request,'dashboard/unitlist.html')

def UserManagementAdd(request):
    return render(request,'dashboard/UserManagementAdd.html')

def UserManagementView(request):
    return render(request,'dashboard/UserManagementView.html')